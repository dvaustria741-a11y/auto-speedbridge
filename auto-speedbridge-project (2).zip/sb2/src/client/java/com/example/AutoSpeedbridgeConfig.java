package com.example;

public class AutoSpeedbridgeConfig {
    public double sneakDistance = 3.5;
    public int waitTicks = 1;
    public boolean rotateYaw = true;
}
