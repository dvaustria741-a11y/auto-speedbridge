package com.example;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class AutoSpeedbridgeConfigManager {

    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "auto-speedbridge.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static AutoSpeedbridgeConfig config = new AutoSpeedbridgeConfig();

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                AutoSpeedbridgeConfig loaded = GSON.fromJson(reader, AutoSpeedbridgeConfig.class);
                if (loaded != null) {
                    config = loaded;
                }
            } catch (Exception e) {
                config = new AutoSpeedbridgeConfig();
            }
        } else {
            save();
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(config, writer);
        } catch (Exception ignored) {
        }
    }
}
