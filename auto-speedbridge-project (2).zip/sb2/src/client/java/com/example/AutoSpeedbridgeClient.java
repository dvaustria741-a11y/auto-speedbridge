package com.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;

public class AutoSpeedbridgeClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        AutoSpeedbridgeConfigManager.load();

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> AutoSpeedbridgeConfigManager.save());

        AutoSpeedbridge.init();
    }
}
