package com.example;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class AutoSpeedbridgeModMenu implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return AutoSpeedbridgeConfigScreen::new;
    }

    private static class AutoSpeedbridgeConfigScreen extends Screen {

        private final Screen parent;

        protected AutoSpeedbridgeConfigScreen(Screen parent) {
            super(Text.literal("AutoSpeedbridge Settings"));
            this.parent = parent;
        }

        @Override
        protected void init() {
            int centerX = this.width / 2;
            int top = this.height / 2 - 50;

            AutoSpeedbridgeConfig cfg = AutoSpeedbridgeConfigManager.config;

            this.addDrawableChild(new SliderWidget(
                    centerX - 100, top, 200, 20,
                    sneakDistanceText(cfg.sneakDistance),
                    (cfg.sneakDistance - 1.0) / 4.0
            ) {
                @Override
                protected void updateMessage() {
                    setMessage(sneakDistanceText(AutoSpeedbridgeConfigManager.config.sneakDistance));
                }

                @Override
                protected void applyValue() {
                    AutoSpeedbridgeConfigManager.config.sneakDistance = 1.0 + this.value * 4.0;
                }
            });

            this.addDrawableChild(new SliderWidget(
                    centerX - 100, top + 24, 200, 20,
                    waitTicksText(cfg.waitTicks),
                    cfg.waitTicks / 5.0
            ) {
                @Override
                protected void updateMessage() {
                    setMessage(waitTicksText(AutoSpeedbridgeConfigManager.config.waitTicks));
                }

                @Override
                protected void applyValue() {
                    AutoSpeedbridgeConfigManager.config.waitTicks = (int) Math.round(this.value * 5.0);
                }
            });

            this.addDrawableChild(ButtonWidget.builder(
                    rotateYawText(cfg.rotateYaw),
                    button -> {
                        AutoSpeedbridgeConfig c = AutoSpeedbridgeConfigManager.config;
                        c.rotateYaw = !c.rotateYaw;
                        button.setMessage(rotateYawText(c.rotateYaw));
                    }
            ).dimensions(centerX - 100, top + 48, 200, 20).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("Done"),
                    button -> this.close()
            ).dimensions(centerX - 100, top + 80, 200, 20).build());
        }

        private static Text sneakDistanceText(double value) {
            return Text.literal(String.format("Sneak Distance: %.2f", value));
        }

        private static Text waitTicksText(int value) {
            return Text.literal("Wait Ticks: " + value);
        }

        private static Text rotateYawText(boolean value) {
            return Text.literal("Auto Rotate Yaw: " + (value ? "ON" : "OFF"));
        }

        @Override
        public void close() {
            AutoSpeedbridgeConfigManager.save();
            this.client.setScreen(parent);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}
