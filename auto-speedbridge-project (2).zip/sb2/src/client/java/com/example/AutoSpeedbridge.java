package com.example;

import com.mojang.blaze3d.platform.InputUtil;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import org.lwjgl.glfw.GLFW;

import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;

public class AutoSpeedbridge {

    private static boolean active = false;
    private static int ticksWaited = 0;
    private static float bridgingYaw;
    private static boolean lockedYaw = false;

    private static KeyBinding toggleKey;

    public static void init() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.auto-speedbridge.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "category.auto-speedbridge"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(AutoSpeedbridge::onTick);
    }

    private static void onTick(MinecraftClient client) {
        while (toggleKey.wasPressed()) {
            toggle(client);
        }

        if (!active) {
            return;
        }

        ClientPlayerEntity player = client.player;
        World world = client.world;
        if (player == null || world == null) {
            stopBridging(client, false);
            return;
        }

        if (ticksWaited < AutoSpeedbridgeConfigManager.config.waitTicks) {
            ticksWaited++;
            return;
        }

        player.setSneaking(true);

        BlockPos feetPos = player.getBlockPos();
        BlockPos belowPos = feetPos.down();

        if (isHanging(player)) {
            speedBridge(client, player, world, belowPos);
            ticksWaited = 0;
        }
    }

    private static void toggle(MinecraftClient client) {
        active = !active;
        ticksWaited = 0;
        lockedYaw = false;

        if (!active) {
            stopBridging(client, true);
        } else if (client.player != null) {
            bridgingYaw = snapYaw(client.player.getYaw());
        }

        if (client.player != null) {
            client.player.sendMessage(Text.literal(
                    "[AutoSpeedbridge] " + (active ? "Enabled" : "Disabled")), true);
        }
    }

    private static void stopBridging(MinecraftClient client, boolean unsneak) {
        active = false;
        ticksWaited = 0;
        lockedYaw = false;
        if (unsneak && client.player != null) {
            client.player.setSneaking(false);
        }
    }

    private static boolean isHanging(ClientPlayerEntity player) {
        return player.fallDistance > 0.0f
                && player.getVelocity().horizontalLength() < 0.001
                || !player.isOnGround();
    }

    private static void speedBridge(MinecraftClient client, ClientPlayerEntity player, World world, BlockPos belowPos) {
        if (!world.getBlockState(belowPos).isAir()) {
            return;
        }

        Optional<Set<Direction>> dirs = getBridgingDirections(player, world, belowPos);
        if (dirs.isEmpty() || dirs.get().isEmpty()) {
            return;
        }

        BlockPos placeAgainst = null;
        Direction placeFace = null;

        for (Direction dir : dirs.get()) {
            BlockPos neighbor = belowPos.offset(dir);
            if (!world.getBlockState(neighbor).isAir()) {
                placeAgainst = neighbor;
                placeFace = dir.getOpposite();
                break;
            }
        }

        if (placeAgainst == null) {
            return;
        }

        int hotbarSlot = findBlockSlot(player);
        if (hotbarSlot == -1) {
            return;
        }

        int prevSlot = player.getInventory().getSelectedSlot();
        player.getInventory().setSelectedSlot(hotbarSlot);

        if (AutoSpeedbridgeConfigManager.config.rotateYaw) {
            player.setYaw(bridgingYaw);
            player.setPitch(90.0f);
        }

        Vec3d hitVec = Vec3d.ofCenter(placeAgainst).add(
                placeFace.getOpposite().getOffsetX() * 0.5,
                placeFace.getOpposite().getOffsetY() * 0.5,
                placeFace.getOpposite().getOffsetZ() * 0.5
        );

        BlockHitResult hitResult = new BlockHitResult(hitVec, placeFace, placeAgainst, false);

        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hitResult);
        client.interactionManager.syncSelectedSlot();

        player.getInventory().setSelectedSlot(prevSlot);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static Optional<Set<Direction>> getBridgingDirections(ClientPlayerEntity player, World world, BlockPos belowPos) {
        Vec3d velocity = player.getVelocity();
        Vec3d look = player.getRotationVector();

        Set<Direction> dirs = EnumSet.noneOf(Direction.class);

        double speed = velocity.horizontalLength();
        float moveYaw = (speed > 0.001)
                ? (float) Math.toDegrees(Math.atan2(-velocity.x, velocity.z))
                : player.getYaw();

        if (!lockedYaw) {
            bridgingYaw = snapYaw(moveYaw);
        }

        Direction primary = Direction.fromHorizontalDegrees(bridgingYaw);
        dirs.add(primary);

        float remainder = ((bridgingYaw % 90) + 90) % 90;
        if (remainder > 22.5f && remainder < 67.5f) {
            dirs.add(Direction.fromHorizontalDegrees(bridgingYaw - 45.0f));
            dirs.add(Direction.fromHorizontalDegrees(bridgingYaw + 45.0f));
        }

        return Optional.of(dirs);
    }

    private static float snapYaw(float yaw) {
        return Math.round(yaw / 45.0f) * 45.0f;
    }

    private static int findBlockSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
                return i;
            }
        }
        return -1;
    }
}
